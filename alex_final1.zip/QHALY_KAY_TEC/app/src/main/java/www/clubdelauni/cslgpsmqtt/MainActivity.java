package www.clubdelauni.cslgpsmqtt;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import org.eclipse.paho.android.service.MqttAndroidClient;
import org.eclipse.paho.client.mqttv3.IMqttActionListener;
import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;

public class MainActivity extends AppCompatActivity {
    EditText MQTTHOST,PUERTO,USERNAME,PASSWORD,TopicStr;
    Integer permiso=0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        MQTTHOST=(EditText)findViewById(R.id.HOST);
        PUERTO=(EditText)findViewById(R.id.PUERTO);
        USERNAME=(EditText)findViewById(R.id.USERNAME);
        PASSWORD=(EditText)findViewById(R.id.PASSWOR);
        TopicStr=(EditText)findViewById(R.id.TOPIC);


    }
    public void CONECTAR_BROKER(View vista){
        String host="tcp://"+MQTTHOST.getText().toString()+":"+PUERTO.getText().toString();
        String username=USERNAME.getText().toString();
        String password=PASSWORD.getText().toString();
        String Topic=TopicStr.getText().toString();
        MqttAndroidClient client;

        String clientId = MqttClient.generateClientId();
        client=new MqttAndroidClient(this.getApplicationContext(),host,clientId);
        MqttConnectOptions options= new MqttConnectOptions();
        options.setUserName(username);
        options.setPassword(password.toCharArray());


        try {
            IMqttToken token = client.connect(options);
            token.setActionCallback(new IMqttActionListener() {
                @Override
                public void onSuccess(IMqttToken asyncActionToken) {
                    // We are connected
                    Toast.makeText(getBaseContext(),"se ha conectado",Toast.LENGTH_SHORT).show();
                    permiso=1;
                }

                @Override
                public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                    // Something went wrong e.g. connection timeout or firewall problems
                    Toast.makeText(getBaseContext(),"No se ha conectado",Toast.LENGTH_SHORT).show();
                    permiso=2;



                }
            });
        } catch (MqttException e) {
            e.printStackTrace();
        }

        if(permiso==1 ){
            Intent pasar=new Intent(this,GpsActivity.class);
            pasar.putExtra("host",host);
            pasar.putExtra("username",username);
            pasar.putExtra("password",password);
            pasar.putExtra("Topic",Topic);

            startActivity(pasar);
            finish();
        }else if (permiso==2){
            Toast.makeText(this,"Rellenar correctamente con el servidor",Toast.LENGTH_SHORT).show();
        }
    }




}
