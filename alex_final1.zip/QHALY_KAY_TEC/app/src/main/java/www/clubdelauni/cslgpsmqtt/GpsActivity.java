package www.clubdelauni.cslgpsmqtt;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.eclipse.paho.android.service.MqttAndroidClient;
import org.eclipse.paho.client.mqttv3.IMqttActionListener;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;

public class GpsActivity extends AppCompatActivity {
    MqttAndroidClient client;
    private TextView Ubicacion;
    private LocationManager locationManager;
    private EditText mensaje;
    private TextView textosuscribir;
    String b="";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gps);
        Ubicacion=(TextView)findViewById(R.id.UBICACION);
        mensaje=(EditText)findViewById(R.id.msg_enviar);
        locationManager=(LocationManager)getSystemService(LOCATION_SERVICE);
        textosuscribir=(TextView)findViewById(R.id.textosuscribir);
        String MQTTHOST=getIntent().getStringExtra("host");
        String USERNAME=getIntent().getStringExtra("username");
        String PASSWORD=getIntent().getStringExtra("password");

        String clientId = MqttClient.generateClientId();
        client=new MqttAndroidClient(this.getApplicationContext(),MQTTHOST,clientId);
        MqttConnectOptions options= new MqttConnectOptions();
        options.setUserName(USERNAME);
        options.setPassword(PASSWORD.toCharArray());


        try {
            IMqttToken token = client.connect(options);
            token.setActionCallback(new IMqttActionListener() {
                @Override
                public void onSuccess(IMqttToken asyncActionToken) {
                    // We are connected
                    Toast.makeText(getBaseContext(),"se ha conectado",Toast.LENGTH_SHORT).show();
                    subscribir();
                }

                @Override
                public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                    // Something went wrong e.g. connection timeout or firewall problems
                    Toast.makeText(getBaseContext(),"No se ha conectado",Toast.LENGTH_SHORT).show();


                }
            });
        } catch (MqttException e) {
            e.printStackTrace();
        }

               if (ContextCompat.checkSelfPermission(GpsActivity.this, Manifest.permission.ACCESS_COARSE_LOCATION)!= PackageManager.PERMISSION_GRANTED &&
                ContextCompat.checkSelfPermission(GpsActivity.this,Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED)
        {
            ActivityCompat.requestPermissions(GpsActivity.this,new String[] {Manifest.permission.ACCESS_COARSE_LOCATION,Manifest.permission.ACCESS_FINE_LOCATION},1);

        }
        locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 1000, 0, new LocationListener() {
            @Override
            public void onLocationChanged(Location location) {
                Ubicacion.setText("Latitud:"+String.valueOf(location.getLatitude())+" Longitud: "+String.valueOf(location.getLongitude()));

            }

            @Override
            public void onStatusChanged(String provider, int status, Bundle extras) {

            }

            @Override
            public void onProviderEnabled(String provider) {

            }

            @Override
            public void onProviderDisabled(String provider) {

            }
        });
        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000, 0, new LocationListener() {
            @Override
            public void onLocationChanged(Location location) {
                Ubicacion.setText("Latidu:"+String.valueOf(location.getLatitude())+" Longitud: "+String.valueOf(location.getLongitude()));
            }

            @Override
            public void onStatusChanged(String provider, int status, Bundle extras) {

            }

            @Override
            public void onProviderEnabled(String provider) {

            }

            @Override
            public void onProviderDisabled(String provider) {

            }
        });

        client.setCallback(new MqttCallback() {


            @Override
            public void connectionLost(Throwable cause) {

            }

            @Override
            public void messageArrived(String topic, MqttMessage message) throws Exception {

                String a =  new String(message.getPayload());

                b= b+a+"\n";

                textosuscribir.setText( b);
            }

            @Override
            public void deliveryComplete(IMqttDeliveryToken token) {

            }
        });

    }public  void enviargps(View vista){
        String topic=getIntent().getStringExtra("Topic");
        String message= getIntent().getStringExtra("username")+": "+Ubicacion.getText().toString();
        try {
            client.publish(topic,message.getBytes(),0,false);

        }catch (Exception e){
            Toast.makeText(GpsActivity.this,"no se pudo enviar "+message,Toast.LENGTH_SHORT).show();

        }

    }
    public void msgenviar(View vista){
        String msg= mensaje.getText().toString();
        String topic=getIntent().getStringExtra("Topic");
        try {
            client.publish(topic,msg.getBytes(),0,false);

        }catch (Exception e){
            Toast.makeText(GpsActivity.this,"no se pudo enviar "+msg,Toast.LENGTH_SHORT).show();

        }

    }
    private  void subscribir(){
        try {String topic=getIntent().getStringExtra("Topic");
            client.subscribe(topic,1);
        }catch (MqttException e){

        }


    }
    public   void limpiar(View vista){textosuscribir.setText("");
        b="";}




    /*public void enviarMsg(View vista){

        TareaAsynck  tareaAsynck= new TareaAsynck();
        tareaAsynck.execute();
    }
    private  class TareaAsynck extends AsyncTask<Void,Integer,String> {

        @Override
        protected  void  onPreExecute(){
            emperor3Segundo();

        }
        @Override
        protected String doInBackground(Void... voids) {
            while (1>0) {
                String topic=getIntent().getStringExtra("Topic");;
                String message= Ubicacion.getText().toString();
                try {
                    client.publish(topic,message.getBytes(),0,false);

                }catch (Exception e){
                    Toast.makeText(GpsActivity.this,"no se pudo enviar "+message,Toast.LENGTH_SHORT).show();

                }
                emperor3Segundo();
            }
        }
        @Override
        protected void onProgressUpdate(Integer... values){

        }
        @Override
        protected void onPostExecute(String Resultado){


        }

    }
    private void emperor3Segundo(){
        try {
            Thread.sleep(3000);
        }catch (InterruptedException e){

        }
    }*/

}
